package server;

public class ServerAppUDP {
    public static void main(String[] args) {
      if (args.length != 1) {
        System.out.println("Usage: java Server <udp-port>");
        System.exit(1);
      }

      int udpPortNumber = Integer.parseInt(args[0]);
      UDPServer server = new UDPServer();
      server.initiateCommunication(udpPortNumber);
    }
}
